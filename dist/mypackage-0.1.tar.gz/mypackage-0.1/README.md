# mypackage
This library was created as an examplr of how to publish yourown Python package.

# How to install
...